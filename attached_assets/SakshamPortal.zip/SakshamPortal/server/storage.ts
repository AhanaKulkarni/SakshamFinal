import { 
  users, 
  subjects, 
  resources, 
  practicals, 
  tutorials, 
  examScores, 
  tasks, 
  activities,
  achievements,
  userAchievements,
  type User, 
  type Subject, 
  type Resource, 
  type Practical, 
  type Tutorial, 
  type ExamScore, 
  type Task, 
  type Activity,
  type Achievement,
  type UserAchievement,
  type InsertUser,
  type InsertSubject,
  type InsertResource,
  type InsertPractical,
  type InsertTutorial,
  type InsertExamScore,
  type InsertTask,
  type InsertActivity,
  type InsertAchievement,
  type InsertUserAchievement
} from "@shared/schema";
import { subjectGroups } from "../client/src/lib/utils";

import session from "express-session";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // Session store
  sessionStore: session.Store;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(userId: number, points: number): Promise<User>;
  updateUserLevel(userId: number, level: number): Promise<User>;
  updateUserStreak(userId: number, streak: number): Promise<User>;
  
  // Subject and resources operations
  getSubjects(group?: string): Promise<Subject[]>;
  getSubjectsWithResources(group?: string): Promise<any[]>;
  getSubjectResources(subjectId: number): Promise<Resource[]>;
  
  // Achievement operations
  getAchievements(): Promise<Achievement[]>;
  getUserAchievements(userId: number): Promise<(UserAchievement & { achievement: Achievement })[]>;
  getAchievement(id: number): Promise<Achievement | undefined>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  createUserAchievement(userAchievement: InsertUserAchievement): Promise<UserAchievement>;
  updateUserAchievementProgress(id: number, currentCount: number): Promise<UserAchievement>;
  completeUserAchievement(id: number): Promise<UserAchievement>;
  getUserStats(userId: number): Promise<any>;
  checkAndUpdateUserAchievements(userId: number): Promise<any[]>;
  
  // Progress tracking operations
  getUserPracticals(userId: number, subjectId?: number): Promise<Practical[]>;
  getUserTutorials(userId: number, subjectId?: number): Promise<Tutorial[]>;
  updatePractical(id: number, completed: boolean): Promise<Practical>;
  updateTutorial(id: number, completed: boolean): Promise<Tutorial>;
  getUserAcademicProgress(userId: number): Promise<any>;
  
  // Exam performance operations
  getUserExamScores(userId: number, period?: string): Promise<ExamScore[]>;
  createExamScore(score: InsertExamScore): Promise<ExamScore>;
  getUserExamPerformance(userId: number, period?: string): Promise<any>;
  resetUserExamScores(userId: number): Promise<void>;
  
  // Task and activity operations
  getUserTasks(userId: number): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, completed: boolean): Promise<Task>;
  getUserActivities(userId: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  
  // Demo data initialization
  initializeDemoData(): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private subjects: Map<number, Subject>;
  private resources: Map<number, Resource>;
  private practicals: Map<number, Practical>;
  private tutorials: Map<number, Tutorial>;
  private examScores: Map<number, ExamScore>;
  private tasks: Map<number, Task>;
  private activities: Map<number, Activity>;
  
  private userIdCounter: number;
  private subjectIdCounter: number;
  private resourceIdCounter: number;
  private practicalIdCounter: number;
  private tutorialIdCounter: number;
  private examScoreIdCounter: number;
  private taskIdCounter: number;
  private activityIdCounter: number;
  
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.subjects = new Map();
    this.resources = new Map();
    this.practicals = new Map();
    this.tutorials = new Map();
    this.examScores = new Map();
    this.tasks = new Map();
    this.activities = new Map();
    
    this.userIdCounter = 1;
    this.subjectIdCounter = 1;
    this.resourceIdCounter = 1;
    this.practicalIdCounter = 1;
    this.tutorialIdCounter = 1;
    this.examScoreIdCounter = 1;
    this.taskIdCounter = 1;
    this.activityIdCounter = 1;
    
    // Create in-memory session store
    const MemoryStore = require('memorystore')(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Subject and resource operations
  async getSubjects(group?: string): Promise<Subject[]> {
    const allSubjects = Array.from(this.subjects.values());
    if (!group) return allSubjects;
    
    return allSubjects.filter(subject => subject.group === group);
  }
  
  async getSubjectsWithResources(group?: string): Promise<any[]> {
    const subjects = await this.getSubjects(group);
    
    return Promise.all(subjects.map(async (subject) => {
      const subjectResources = await this.getSubjectResources(subject.id);
      
      return {
        ...subject,
        resourceCount: subjectResources.length,
        resources: subjectResources
      };
    }));
  }
  
  async getSubjectResources(subjectId: number): Promise<Resource[]> {
    return Array.from(this.resources.values()).filter(
      resource => resource.subjectId === subjectId
    );
  }
  
  // Progress tracking operations
  async getUserPracticals(userId: number, subjectId?: number): Promise<Practical[]> {
    const userPracticals = Array.from(this.practicals.values()).filter(
      practical => practical.userId === userId
    );
    
    if (!subjectId) return userPracticals;
    
    return userPracticals.filter(
      practical => practical.subjectId === subjectId
    );
  }
  
  async getUserTutorials(userId: number, subjectId?: number): Promise<Tutorial[]> {
    const userTutorials = Array.from(this.tutorials.values()).filter(
      tutorial => tutorial.userId === userId
    );
    
    if (!subjectId) return userTutorials;
    
    return userTutorials.filter(
      tutorial => tutorial.subjectId === subjectId
    );
  }
  
  async updatePractical(id: number, completed: boolean): Promise<Practical> {
    const practical = this.practicals.get(id);
    
    if (!practical) {
      throw new Error(`Practical with ID ${id} not found`);
    }
    
    const updatedPractical: Practical = {
      ...practical,
      completed,
      completedAt: completed ? new Date() : null
    };
    
    this.practicals.set(id, updatedPractical);
    return updatedPractical;
  }
  
  async updateTutorial(id: number, completed: boolean): Promise<Tutorial> {
    const tutorial = this.tutorials.get(id);
    
    if (!tutorial) {
      throw new Error(`Tutorial with ID ${id} not found`);
    }
    
    const updatedTutorial: Tutorial = {
      ...tutorial,
      completed,
      completedAt: completed ? new Date() : null
    };
    
    this.tutorials.set(id, updatedTutorial);
    return updatedTutorial;
  }
  
  async getUserAcademicProgress(userId: number): Promise<any> {
    const allSubjects = await this.getSubjects();
    const subjectProgress = [];
    
    let group1CompletedCount = 0;
    let group1TotalCount = 0;
    let group2CompletedCount = 0;
    let group2TotalCount = 0;
    
    for (const subject of allSubjects) {
      const practicals = await this.getUserPracticals(userId, subject.id);
      const tutorials = await this.getUserTutorials(userId, subject.id);
      
      const practicalCompleted = practicals.filter(p => p.completed).length;
      const tutorialCompleted = tutorials.filter(t => t.completed).length;
      
      const practicalTotal = practicals.length;
      const tutorialTotal = tutorials.length || 1; // Avoid division by zero
      
      // Calculate overall progress for this subject (average of practicals and tutorials)
      const overallProgress = Math.round(
        ((practicalCompleted / practicalTotal) + (tutorialCompleted / tutorialTotal)) * 50
      );
      
      // Add to group totals
      if (subject.group === 'group1') {
        group1CompletedCount += practicalCompleted + tutorialCompleted;
        group1TotalCount += practicalTotal + tutorialTotal;
      } else if (subject.group === 'group2') {
        group2CompletedCount += practicalCompleted + tutorialCompleted;
        group2TotalCount += practicalTotal + tutorialTotal;
      }
      
      subjectProgress.push({
        id: subject.id,
        name: subject.name,
        icon: subject.icon,
        group: subject.group,
        practicals: {
          completed: practicalCompleted,
          total: practicalTotal
        },
        tutorials: {
          completed: tutorialCompleted,
          total: tutorialTotal
        },
        overall: overallProgress
      });
    }
    
    // Calculate group progress percentages
    const group1Progress = group1TotalCount > 0 
      ? Math.round((group1CompletedCount / group1TotalCount) * 100) 
      : 0;
      
    const group2Progress = group2TotalCount > 0 
      ? Math.round((group2CompletedCount / group2TotalCount) * 100) 
      : 0;
    
    return {
      group1Progress,
      group2Progress,
      subjectProgress
    };
  }
  
  // Exam performance operations
  async getUserExamScores(userId: number, period?: string): Promise<ExamScore[]> {
    const userScores = Array.from(this.examScores.values()).filter(
      score => score.userId === userId
    );
    
    if (!period || period === 'all') return userScores;
    
    // Filter by period (current/previous semester)
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();
    const isCurrSemFirstHalf = currentMonth < 6; // First half of the year
    
    return userScores.filter(score => {
      const scoreDate = new Date(score.date);
      const scoreYear = scoreDate.getFullYear();
      const scoreMonth = scoreDate.getMonth();
      const isScoreSemFirstHalf = scoreMonth < 6;
      
      if (period === 'current') {
        // Current semester
        return (
          scoreYear === currentYear && 
          isScoreSemFirstHalf === isCurrSemFirstHalf
        );
      } else if (period === 'previous') {
        // Previous semester
        if (isCurrSemFirstHalf) {
          // If current is first half, previous is second half of last year
          return (
            (scoreYear === currentYear - 1) && 
            !isScoreSemFirstHalf
          );
        } else {
          // If current is second half, previous is first half of current year
          return (
            (scoreYear === currentYear) && 
            isScoreSemFirstHalf
          );
        }
      }
      
      return true;
    });
  }
  
  async createExamScore(score: InsertExamScore): Promise<ExamScore> {
    const id = this.examScoreIdCounter++;
    const examScore: ExamScore = { ...score, id };
    this.examScores.set(id, examScore);
    return examScore;
  }
  
  async resetUserExamScores(userId: number): Promise<void> {
    try {
      // Delete all exam scores for the specified user
      for (const [id, examScore] of this.examScores.entries()) {
        if (examScore.userId === userId) {
          this.examScores.delete(id);
        }
      }
      
      console.log(`All exam scores deleted for user ID: ${userId}`);
    } catch (error) {
      console.error(`Error resetting exam scores for user ID: ${userId}`, error);
      throw error;
    }
  }
  
  async getUserExamPerformance(userId: number, period?: string): Promise<any> {
    const scores = await this.getUserExamScores(userId, period);
    
    if (scores.length === 0) {
      return {
        examScores: [],
        subjectPerformance: [],
        overallTrend: []
      };
    }
    
    // Group scores by subject
    const scoresBySubject = scores.reduce((acc, score) => {
      if (!acc[score.subjectId]) {
        acc[score.subjectId] = [];
      }
      acc[score.subjectId].push(score);
      return acc;
    }, {} as Record<number, ExamScore[]>);
    
    // Calculate performance by subject
    const subjectPerformance = await Promise.all(
      Object.entries(scoresBySubject).map(async ([subjectId, subjectScores]) => {
        const subject = this.subjects.get(parseInt(subjectId));
        
        if (!subject) return null;
        
        // Calculate average score for this subject
        const totalPercentage = subjectScores.reduce((sum, score) => {
          return sum + ((score.marks / score.totalMarks) * 100);
        }, 0);
        
        const averageScore = Math.round(totalPercentage / subjectScores.length);
        
        // Create trend data
        const trend = subjectScores.map(score => ({
          testName: score.testName,
          score: Math.round((score.marks / score.totalMarks) * 100)
        }));
        
        return {
          id: subject.id,
          name: subject.name,
          averageScore,
          trend
        };
      })
    );
    
    // Create overall trend data (by month)
    const scoresByMonth: Record<string, number[]> = {};
    
    scores.forEach(score => {
      const date = new Date(score.date);
      const monthYear = `${date.toLocaleString('default', { month: 'short' })} ${date.getFullYear()}`;
      
      if (!scoresByMonth[monthYear]) {
        scoresByMonth[monthYear] = [];
      }
      
      scoresByMonth[monthYear].push((score.marks / score.totalMarks) * 100);
    });
    
    const overallTrend = Object.entries(scoresByMonth).map(([month, percentages]) => {
      const avgScore = Math.round(
        percentages.reduce((sum, percentage) => sum + percentage, 0) / percentages.length
      );
      
      return {
        month,
        score: avgScore
      };
    });
    
    // Sort by chronological order
    overallTrend.sort((a, b) => {
      const [monthA, yearA] = a.month.split(' ');
      const [monthB, yearB] = b.month.split(' ');
      
      if (yearA !== yearB) return parseInt(yearA) - parseInt(yearB);
      
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      return months.indexOf(monthA) - months.indexOf(monthB);
    });
    
    return {
      examScores: scores,
      subjectPerformance: subjectPerformance.filter(Boolean),
      overallTrend
    };
  }
  
  // Task and activity operations
  async getUserTasks(userId: number): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .filter(task => task.userId === userId && !task.completed)
      .sort((a, b) => {
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      });
  }
  
  async createTask(task: InsertTask): Promise<Task> {
    const id = this.taskIdCounter++;
    const newTask: Task = { ...task, id };
    this.tasks.set(id, newTask);
    return newTask;
  }
  
  async updateTask(id: number, completed: boolean): Promise<Task> {
    const task = this.tasks.get(id);
    
    if (!task) {
      throw new Error(`Task with ID ${id} not found`);
    }
    
    const updatedTask: Task = {
      ...task,
      completed,
      completedAt: completed ? new Date() : null
    };
    
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }
  
  async getUserActivities(userId: number): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .filter(activity => activity.userId === userId)
      .sort((a, b) => {
        return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
      })
      .slice(0, 10); // Return only the 10 most recent activities
  }
  
  async createActivity(activity: InsertActivity): Promise<Activity> {
    const id = this.activityIdCounter++;
    const newActivity: Activity = { ...activity, id };
    this.activities.set(id, newActivity);
    return newActivity;
  }
  
  // Demo data initialization
  async initializeDemoData(): Promise<void> {
    // Check if data already exists
    if (this.users.size > 0) return;
    
    // Create demo user
    const demoUser: InsertUser = {
      username: "student_demo",
      password: "password123",
      name: "Student Demo",
      email: "student@tcetmumbai.in"
    };
    
    const user = await this.createUser(demoUser);
    
    // Create subjects (Group 1)
    for (const subjectData of subjectGroups.group1) {
      const subject: InsertSubject = {
        name: subjectData.name,
        icon: subjectData.icon,
        color: subjectData.color,
        group: "group1"
      };
      
      const createdSubject = await this.createSubject(subject);
      
      // Create resources for this subject
      await this.createResourcesForSubject(createdSubject.id, subjectData.name);
      
      // Create practicals and tutorials
      await this.createPracticalsForSubject(user.id, createdSubject.id);
      
      if (subjectData.name.includes("Math")) {
        await this.createTutorialsForSubject(user.id, createdSubject.id);
      }
      
      // Create some exam scores
      await this.createExamScoresForSubject(user.id, createdSubject.id);
    }
    
    // Create subjects (Group 2)
    for (const subjectData of subjectGroups.group2) {
      const subject: InsertSubject = {
        name: subjectData.name,
        icon: subjectData.icon,
        color: subjectData.color,
        group: "group2"
      };
      
      const createdSubject = await this.createSubject(subject);
      
      // Create resources for this subject
      await this.createResourcesForSubject(createdSubject.id, subjectData.name);
      
      // Create practicals and tutorials
      await this.createPracticalsForSubject(user.id, createdSubject.id);
      
      if (subjectData.name.includes("Math")) {
        await this.createTutorialsForSubject(user.id, createdSubject.id);
      }
      
      // Create some exam scores
      await this.createExamScoresForSubject(user.id, createdSubject.id);
    }
    
    // Create demo tasks
    const tasks: InsertTask[] = [
      {
        userId: user.id,
        title: "Submit Physics Practical 7",
        description: "Complete and submit the practical report for experiment 7",
        dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // Tomorrow
        priority: "High",
        completed: false
      },
      {
        userId: user.id,
        title: "Complete Math Tutorial 5",
        description: "Solve all problems in tutorial sheet 5",
        dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
        priority: "Medium",
        completed: false
      },
      {
        userId: user.id,
        title: "Review BEE Notes for Quiz",
        description: "Go through chapter 4 and 5 notes for upcoming quiz",
        dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
        priority: "Low",
        completed: false
      }
    ];
    
    for (const task of tasks) {
      await this.createTask(task);
    }
    
    // Create demo activities
    const activities: InsertActivity[] = [
      {
        userId: user.id,
        title: "Completed Chemistry Practical 6",
        type: "success",
        timestamp: new Date()
      },
      {
        userId: user.id,
        title: "Accessed Math Resources",
        type: "primary",
        timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) // Yesterday
      },
      {
        userId: user.id,
        title: "Updated Progress Tracker",
        type: "info",
        timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) // Yesterday
      },
      {
        userId: user.id,
        title: "Submitted Physics Assignment",
        type: "warning",
        timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) // 5 days ago
      }
    ];
    
    for (const activity of activities) {
      await this.createActivity(activity);
    }
  }
  
  // Helper methods for initialization
  private async createSubject(subject: InsertSubject): Promise<Subject> {
    const id = this.subjectIdCounter++;
    const newSubject: Subject = { ...subject, id };
    this.subjects.set(id, newSubject);
    return newSubject;
  }
  
  private async createResourcesForSubject(subjectId: number, subjectName: string): Promise<void> {
    // Create e-books
    const ebookResource: InsertResource = {
      subjectId,
      title: `${subjectName} Fundamentals (PDF)`,
      type: "ebook",
      url: "#",
      description: `Comprehensive ${subjectName} textbook`,
      icon: "ri-file-pdf-line mr-2"
    };
    await this.createResource(ebookResource);
    
    // Create video resources
    const videoResource: InsertResource = {
      subjectId,
      title: `${subjectName} Concepts Playlist`,
      type: "video",
      url: "#",
      description: `Curated YouTube playlist on ${subjectName}`,
      icon: "ri-youtube-line mr-2 text-error"
    };
    await this.createResource(videoResource);
    
    // Create online resources
    const onlineResource: InsertResource = {
      subjectId,
      title: `${subjectName} Interactive Tools`,
      type: "online",
      url: "#",
      description: `Interactive online tools for ${subjectName}`,
      icon: "ri-global-line mr-2 text-info"
    };
    await this.createResource(onlineResource);
  }
  
  private async createResource(resource: InsertResource): Promise<Resource> {
    const id = this.resourceIdCounter++;
    const newResource: Resource = { ...resource, id };
    this.resources.set(id, newResource);
    return newResource;
  }
  
  private async createPracticalsForSubject(userId: number, subjectId: number): Promise<void> {
    // Create 10 practicals per subject
    for (let i = 1; i <= 10; i++) {
      const subject = this.subjects.get(subjectId);
      
      if (!subject) continue;
      
      const practical: InsertPractical = {
        userId,
        subjectId,
        name: `${subject.name} Practical ${i}`,
        completed: i <= Math.floor(Math.random() * 7) + 1, // Randomly complete some practicals (between 1-8)
        completedAt: null
      };
      
      if (practical.completed) {
        practical.completedAt = new Date(Date.now() - Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000);
      }
      
      const id = this.practicalIdCounter++;
      const newPractical: Practical = { ...practical, id };
      this.practicals.set(id, newPractical);
    }
  }
  
  private async createTutorialsForSubject(userId: number, subjectId: number): Promise<void> {
    // Create 10 tutorials for math subjects
    for (let i = 1; i <= 10; i++) {
      const subject = this.subjects.get(subjectId);
      
      if (!subject) continue;
      
      const tutorial: InsertTutorial = {
        userId,
        subjectId,
        name: `${subject.name} Tutorial ${i}`,
        completed: i <= Math.floor(Math.random() * 6) + 1, // Randomly complete some tutorials (between 1-7)
        completedAt: null
      };
      
      if (tutorial.completed) {
        tutorial.completedAt = new Date(Date.now() - Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000);
      }
      
      const id = this.tutorialIdCounter++;
      const newTutorial: Tutorial = { ...tutorial, id };
      this.tutorials.set(id, newTutorial);
    }
  }
  
  private async createExamScoresForSubject(userId: number, subjectId: number): Promise<void> {
    const subject = this.subjects.get(subjectId);
    if (!subject) return;
    
    const testTypes = ["Quiz", "Mid-Term", "Assignment", "Final"];
    
    // Generate some scores for the past 6 months
    for (let i = 0; i < 3; i++) {
      const monthsAgo = i * 2; // 0, 2, 4 months ago
      const testName = `${testTypes[i % testTypes.length]} ${i + 1}`;
      const totalMarks = 100;
      const marks = Math.floor(Math.random() * 41) + 50; // Random mark between 50-90
      
      const scoreDate = new Date();
      scoreDate.setMonth(scoreDate.getMonth() - monthsAgo);
      
      const examScore: InsertExamScore = {
        userId,
        subjectId,
        testName,
        marks,
        totalMarks,
        date: scoreDate
      };
      
      const id = this.examScoreIdCounter++;
      const newExamScore: ExamScore = { ...examScore, id };
      this.examScores.set(id, newExamScore);
    }
  }
}

import { DatabaseStorage } from "./database-storage";

export const storage = new DatabaseStorage();
