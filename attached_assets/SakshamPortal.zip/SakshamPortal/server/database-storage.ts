import { 
  User, 
  Subject, 
  Resource, 
  Practical, 
  Tutorial, 
  ExamScore, 
  Task, 
  Activity,
  Achievement,
  UserAchievement,
  InsertUser,
  InsertSubject,
  InsertResource,
  InsertPractical,
  InsertTutorial,
  InsertExamScore,
  InsertTask,
  InsertActivity,
  InsertAchievement,
  InsertUserAchievement,
  users,
  subjects,
  resources,
  practicals,
  tutorials,
  examScores,
  tasks,
  activities,
  achievements,
  userAchievements
} from "@shared/schema";
import { db } from "./db";
import { eq, and, sql, desc, asc, count, isNull, gt, sum } from "drizzle-orm";
import { IStorage } from "./storage";
import { subjectGroups } from "../client/src/lib/utils";
import connectPgSimple from "connect-pg-simple";
import session from "express-session";
import { pool } from "./db";

// Set up session store
const PgStore = connectPgSimple(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PgStore({
      pool,
      createTableIfMissing: true
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values({
      ...insertUser,
      points: 0,
      level: 1,
      streak: 0
    }).returning();
    return user;
  }
  
  async updateUserPoints(userId: number, points: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ points })
      .where(eq(users.id, userId))
      .returning();
    
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    return user;
  }
  
  async updateUserLevel(userId: number, level: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ level })
      .where(eq(users.id, userId))
      .returning();
    
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    return user;
  }
  
  async updateUserStreak(userId: number, streak: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        streak,
        lastActivityDate: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    return user;
  }

  // Subject and resource operations
  async getSubjects(group?: string): Promise<Subject[]> {
    if (!group) {
      return db.select().from(subjects);
    }
    
    return db.select().from(subjects).where(eq(subjects.group, group));
  }

  async getSubjectsWithResources(group?: string): Promise<any[]> {
    const allSubjects = await this.getSubjects(group);
    
    return Promise.all(allSubjects.map(async (subject) => {
      const subjectResources = await this.getSubjectResources(subject.id);
      
      return {
        ...subject,
        resourceCount: subjectResources.length,
        resources: subjectResources
      };
    }));
  }

  async getSubjectResources(subjectId: number): Promise<Resource[]> {
    return db.select().from(resources).where(eq(resources.subjectId, subjectId));
  }

  // Progress tracking operations
  async getUserPracticals(userId: number, subjectId?: number): Promise<Practical[]> {
    if (!subjectId) {
      return db.select().from(practicals).where(eq(practicals.userId, userId));
    }
    
    return db.select().from(practicals).where(
      and(
        eq(practicals.userId, userId),
        eq(practicals.subjectId, subjectId)
      )
    );
  }

  async getUserTutorials(userId: number, subjectId?: number): Promise<Tutorial[]> {
    if (!subjectId) {
      return db.select().from(tutorials).where(eq(tutorials.userId, userId));
    }
    
    return db.select().from(tutorials).where(
      and(
        eq(tutorials.userId, userId),
        eq(tutorials.subjectId, subjectId)
      )
    );
  }

  async updatePractical(id: number, completed: boolean): Promise<Practical> {
    const completedAt = completed ? new Date() : null;
    
    const [updatedPractical] = await db
      .update(practicals)
      .set({ completed, completedAt })
      .where(eq(practicals.id, id))
      .returning();
    
    if (!updatedPractical) {
      throw new Error(`Practical with ID ${id} not found`);
    }
    
    return updatedPractical;
  }

  async updateTutorial(id: number, completed: boolean): Promise<Tutorial> {
    const completedAt = completed ? new Date() : null;
    
    const [updatedTutorial] = await db
      .update(tutorials)
      .set({ completed, completedAt })
      .where(eq(tutorials.id, id))
      .returning();
    
    if (!updatedTutorial) {
      throw new Error(`Tutorial with ID ${id} not found`);
    }
    
    return updatedTutorial;
  }

  async getUserAcademicProgress(userId: number): Promise<any> {
    const allSubjects = await this.getSubjects();
    const subjectProgress = [];
    
    let group1CompletedCount = 0;
    let group1TotalCount = 0;
    let group2CompletedCount = 0;
    let group2TotalCount = 0;
    
    for (const subject of allSubjects) {
      const practicals = await this.getUserPracticals(userId, subject.id);
      const tutorials = await this.getUserTutorials(userId, subject.id);
      
      const practicalCompleted = practicals.filter(p => p.completed).length;
      const tutorialCompleted = tutorials.filter(t => t.completed).length;
      
      const practicalTotal = practicals.length;
      const tutorialTotal = tutorials.length || 1; // Avoid division by zero
      
      // Calculate overall progress for this subject (average of practicals and tutorials)
      const overallProgress = Math.round(
        ((practicalCompleted / practicalTotal) + (tutorialCompleted / tutorialTotal)) * 50
      );
      
      // Add to group totals
      if (subject.group === 'group1') {
        group1CompletedCount += practicalCompleted + tutorialCompleted;
        group1TotalCount += practicalTotal + tutorialTotal;
      } else if (subject.group === 'group2') {
        group2CompletedCount += practicalCompleted + tutorialCompleted;
        group2TotalCount += practicalTotal + tutorialTotal;
      }
      
      subjectProgress.push({
        id: subject.id,
        name: subject.name,
        icon: subject.icon,
        group: subject.group,
        practicals: {
          completed: practicalCompleted,
          total: practicalTotal
        },
        tutorials: {
          completed: tutorialCompleted,
          total: tutorialTotal
        },
        overall: overallProgress
      });
    }
    
    // Calculate group progress percentages
    const group1Progress = group1TotalCount > 0 
      ? Math.round((group1CompletedCount / group1TotalCount) * 100) 
      : 0;
      
    const group2Progress = group2TotalCount > 0 
      ? Math.round((group2CompletedCount / group2TotalCount) * 100) 
      : 0;
    
    return {
      group1Progress,
      group2Progress,
      subjectProgress
    };
  }

  // Exam performance operations
  async getUserExamScores(userId: number, period?: string): Promise<ExamScore[]> {
    const userScores = await db
      .select()
      .from(examScores)
      .where(eq(examScores.userId, userId));
    
    if (!period || period === 'all') return userScores;
    
    // Filter by period (current/previous semester)
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();
    const isCurrSemFirstHalf = currentMonth < 6; // First half of the year
    
    return userScores.filter(score => {
      const scoreDate = new Date(score.date);
      const scoreYear = scoreDate.getFullYear();
      const scoreMonth = scoreDate.getMonth();
      const isScoreSemFirstHalf = scoreMonth < 6;
      
      if (period === 'current') {
        // Current semester
        return (
          scoreYear === currentYear && 
          isScoreSemFirstHalf === isCurrSemFirstHalf
        );
      } else if (period === 'previous') {
        // Previous semester
        if (isCurrSemFirstHalf) {
          // If current is first half, previous is second half of last year
          return (
            (scoreYear === currentYear - 1) && 
            !isScoreSemFirstHalf
          );
        } else {
          // If current is second half, previous is first half of current year
          return (
            (scoreYear === currentYear) && 
            isScoreSemFirstHalf
          );
        }
      }
      
      return true;
    });
  }

  async createExamScore(score: InsertExamScore): Promise<ExamScore> {
    const [examScore] = await db
      .insert(examScores)
      .values(score)
      .returning();
    
    return examScore;
  }
  
  async resetUserExamScores(userId: number): Promise<void> {
    try {
      // Delete all exam scores for the user instead of setting to zero
      // This is more appropriate as we want to start fresh
      await db
        .delete(examScores)
        .where(eq(examScores.userId, userId));
      
      console.log(`All exam scores deleted for user ID: ${userId}`);
    } catch (error) {
      console.error(`Error resetting exam scores for user ID: ${userId}`, error);
      throw error;
    }
  }

  async getUserExamPerformance(userId: number, period?: string): Promise<any> {
    const scores = await this.getUserExamScores(userId, period);
    
    if (scores.length === 0) {
      return {
        examScores: [],
        subjectPerformance: [],
        overallTrend: []
      };
    }
    
    // Group scores by subject
    const scoresBySubject = scores.reduce((acc, score) => {
      if (!acc[score.subjectId]) {
        acc[score.subjectId] = [];
      }
      acc[score.subjectId].push(score);
      return acc;
    }, {} as Record<number, ExamScore[]>);
    
    // Calculate performance by subject
    const subjectPerformance = await Promise.all(
      Object.entries(scoresBySubject).map(async ([subjectId, subjectScores]) => {
        const [subject] = await db
          .select()
          .from(subjects)
          .where(eq(subjects.id, parseInt(subjectId)));
        
        if (!subject) return null;
        
        // Calculate average score for this subject
        const totalPercentage = subjectScores.reduce((sum, score) => {
          return sum + ((score.marks / score.totalMarks) * 100);
        }, 0);
        
        const averageScore = Math.round(totalPercentage / subjectScores.length);
        
        // Create trend data
        const trend = subjectScores.map(score => ({
          testName: score.testName,
          score: Math.round((score.marks / score.totalMarks) * 100)
        }));
        
        return {
          id: subject.id,
          name: subject.name,
          averageScore,
          trend
        };
      })
    );
    
    // Create overall trend data (by month)
    const scoresByMonth: Record<string, number[]> = {};
    
    scores.forEach(score => {
      const date = new Date(score.date);
      const monthYear = `${date.toLocaleString('default', { month: 'short' })} ${date.getFullYear()}`;
      
      if (!scoresByMonth[monthYear]) {
        scoresByMonth[monthYear] = [];
      }
      
      scoresByMonth[monthYear].push((score.marks / score.totalMarks) * 100);
    });
    
    const overallTrend = Object.entries(scoresByMonth).map(([month, percentages]) => {
      const avgScore = Math.round(
        percentages.reduce((sum, percentage) => sum + percentage, 0) / percentages.length
      );
      
      return {
        month,
        score: avgScore
      };
    });
    
    // Sort by chronological order
    overallTrend.sort((a, b) => {
      const [monthA, yearA] = a.month.split(' ');
      const [monthB, yearB] = b.month.split(' ');
      
      if (yearA !== yearB) return parseInt(yearA) - parseInt(yearB);
      
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      return months.indexOf(monthA) - months.indexOf(monthB);
    });
    
    return {
      examScores: scores,
      subjectPerformance: subjectPerformance.filter(Boolean),
      overallTrend
    };
  }

  // Task and activity operations
  async getUserTasks(userId: number): Promise<Task[]> {
    return db
      .select()
      .from(tasks)
      .where(
        and(
          eq(tasks.userId, userId),
          eq(tasks.completed, false)
        )
      )
      .orderBy(
        sql`CASE WHEN ${tasks.dueDate} IS NULL THEN 1 ELSE 0 END`,
        tasks.dueDate
      );
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db
      .insert(tasks)
      .values(task)
      .returning();
    
    return newTask;
  }

  async updateTask(id: number, completed: boolean): Promise<Task> {
    const completedAt = completed ? new Date() : null;
    
    const [updatedTask] = await db
      .update(tasks)
      .set({ completed, completedAt })
      .where(eq(tasks.id, id))
      .returning();
    
    if (!updatedTask) {
      throw new Error(`Task with ID ${id} not found`);
    }
    
    return updatedTask;
  }

  async getUserActivities(userId: number): Promise<Activity[]> {
    return db
      .select()
      .from(activities)
      .where(eq(activities.userId, userId))
      .orderBy(desc(activities.timestamp))
      .limit(10); // Return only the 10 most recent activities
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [newActivity] = await db
      .insert(activities)
      .values(activity)
      .returning();
    
    return newActivity;
  }
  
  // Achievement operations
  async getAchievements(): Promise<Achievement[]> {
    return db.select().from(achievements);
  }
  
  async getUserAchievements(userId: number): Promise<(UserAchievement & { achievement: Achievement })[]> {
    const userAchievementsData = await db
      .select()
      .from(userAchievements)
      .where(eq(userAchievements.userId, userId));
      
    const result = [];
    
    for (const userAchievement of userAchievementsData) {
      const [achievement] = await db
        .select()
        .from(achievements)
        .where(eq(achievements.id, userAchievement.achievementId));
      
      if (achievement) {
        result.push({
          ...userAchievement,
          achievement
        });
      }
    }
    
    return result;
  }
  
  async getAchievement(id: number): Promise<Achievement | undefined> {
    const [achievement] = await db
      .select()
      .from(achievements)
      .where(eq(achievements.id, id));
    
    return achievement;
  }
  
  async createAchievement(achievement: InsertAchievement): Promise<Achievement> {
    const [newAchievement] = await db
      .insert(achievements)
      .values(achievement)
      .returning();
    
    return newAchievement;
  }
  
  async createUserAchievement(userAchievement: InsertUserAchievement): Promise<UserAchievement> {
    const [newUserAchievement] = await db
      .insert(userAchievements)
      .values(userAchievement)
      .returning();
    
    return newUserAchievement;
  }
  
  async updateUserAchievementProgress(id: number, currentCount: number): Promise<UserAchievement> {
    const [userAchievement] = await db
      .update(userAchievements)
      .set({ currentCount })
      .where(eq(userAchievements.id, id))
      .returning();
    
    if (!userAchievement) {
      throw new Error(`User achievement with ID ${id} not found`);
    }
    
    return userAchievement;
  }
  
  async completeUserAchievement(id: number): Promise<UserAchievement> {
    const [userAchievement] = await db
      .update(userAchievements)
      .set({ 
        completed: true,
        unlockedAt: new Date()
      })
      .where(eq(userAchievements.id, id))
      .returning();
    
    if (!userAchievement) {
      throw new Error(`User achievement with ID ${id} not found`);
    }
    
    return userAchievement;
  }
  
  async getUserStats(userId: number): Promise<any> {
    const user = await this.getUser(userId);
    
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    // Count completed tasks
    const completedTasksResult = await db
      .select({ count: count() })
      .from(tasks)
      .where(
        and(
          eq(tasks.userId, userId),
          eq(tasks.completed, true)
        )
      );
    
    const completedTasks = Number(completedTasksResult[0].count) || 0;
    
    // Count completed practicals
    const completedPracticalsResult = await db
      .select({ count: count() })
      .from(practicals)
      .where(
        and(
          eq(practicals.userId, userId),
          eq(practicals.completed, true)
        )
      );
    
    const completedPracticals = Number(completedPracticalsResult[0].count) || 0;
    
    // Count completed tutorials
    const completedTutorialsResult = await db
      .select({ count: count() })
      .from(tutorials)
      .where(
        and(
          eq(tutorials.userId, userId),
          eq(tutorials.completed, true)
        )
      );
    
    const completedTutorials = Number(completedTutorialsResult[0].count) || 0;
    
    // Count exam scores with >80%
    const examScoresResult = await db
      .select()
      .from(examScores)
      .where(eq(examScores.userId, userId));
    
    const highScoringExams = examScoresResult.filter(score => 
      (score.marks / score.totalMarks) * 100 >= 80
    ).length;
    
    // Get user achievements
    const userAchievementsData = await this.getUserAchievements(userId);
    const unlockedAchievements = userAchievementsData.filter(ua => ua.completed).length;
    
    return {
      user: {
        name: user.name,
        points: user.points,
        level: user.level,
        streak: user.streak,
        lastActivityDate: user.lastActivityDate
      },
      stats: {
        completedTasks,
        completedPracticals,
        completedTutorials,
        highScoringExams,
        unlockedAchievements,
        totalAchievements: userAchievementsData.length
      }
    };
  }
  
  async checkAndUpdateUserAchievements(userId: number): Promise<any[]> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    // Get user's current stats
    const stats = await this.getUserStats(userId);
    
    // Get user's achievements
    const userAchievementsData = await this.getUserAchievements(userId);
    
    const unlockedAchievements = [];
    
    // Check each achievement condition
    for (const userAchievement of userAchievementsData) {
      if (userAchievement.completed) continue; // Skip already completed
      
      const { achievement } = userAchievement;
      let progress = userAchievement.currentCount;
      let completed = false;
      
      // Check conditions based on achievement category
      switch (achievement.category) {
        case 'tasks':
          progress = stats.stats.completedTasks;
          completed = progress >= achievement.requiredCount;
          break;
        case 'practicals':
          progress = stats.stats.completedPracticals;
          completed = progress >= achievement.requiredCount;
          break;
        case 'tutorials':
          progress = stats.stats.completedTutorials;
          completed = progress >= achievement.requiredCount;
          break;
        case 'exams':
          progress = stats.stats.highScoringExams;
          completed = progress >= achievement.requiredCount;
          break;
        case 'streak':
          progress = user.streak;
          completed = progress >= achievement.requiredCount;
          break;
      }
      
      // Update progress
      if (progress !== userAchievement.currentCount) {
        await this.updateUserAchievementProgress(userAchievement.id, progress);
      }
      
      // Complete achievement if progress meets requirement
      if (completed && !userAchievement.completed) {
        const updatedAchievement = await this.completeUserAchievement(userAchievement.id);
        
        // Add points to user
        const newPoints = user.points + achievement.pointsAwarded;
        await this.updateUserPoints(userId, newPoints);
        
        // Add to unlocked achievements list
        unlockedAchievements.push({
          ...updatedAchievement,
          achievement
        });
        
        // Create activity for unlocking achievement
        await this.createActivity({
          userId,
          title: `Unlocked achievement: ${achievement.name}`,
          type: 'success',
          timestamp: new Date()
        });
      }
    }
    
    return unlockedAchievements;
  }

  // Helper method to create a subject
  private async createSubject(subject: InsertSubject): Promise<Subject> {
    const [newSubject] = await db
      .insert(subjects)
      .values(subject)
      .returning();
    
    return newSubject;
  }

  // Helper method to create resources for a subject
  private async createResourcesForSubject(subjectId: number, subjectName: string): Promise<void> {
    // E-book resource
    const ebookResource: InsertResource = {
      subjectId,
      title: `${subjectName} E-book`,
      type: 'ebook',
      url: '#',
      description: `Comprehensive ${subjectName} e-book with examples and exercises`,
      icon: 'book'
    };
    
    // Video resource
    const videoResource: InsertResource = {
      subjectId,
      title: `${subjectName} Video Lectures`,
      type: 'video',
      url: '#',
      description: `Video lectures on ${subjectName} concepts`,
      icon: 'video'
    };
    
    // Online resource
    const onlineResource: InsertResource = {
      subjectId,
      title: `${subjectName} Online Portal`,
      type: 'online',
      url: '#',
      description: `Interactive online portal for ${subjectName}`,
      icon: 'globe'
    };
    
    await db.insert(resources).values([ebookResource, videoResource, onlineResource]);
  }

  // Helper method to create practicals for a subject
  private async createPracticalsForSubject(userId: number, subjectId: number): Promise<void> {
    const practicalCount = 8;
    const batchInsert = [];
    
    for (let i = 1; i <= practicalCount; i++) {
      const practical: InsertPractical = {
        userId,
        subjectId,
        name: `Practical ${i}`,
        completed: Math.random() > 0.5, // Randomly mark some as completed
        completedAt: Math.random() > 0.5 ? new Date() : null
      };
      
      batchInsert.push(practical);
    }
    
    await db.insert(practicals).values(batchInsert);
  }

  // Helper method to create tutorials for a subject
  private async createTutorialsForSubject(userId: number, subjectId: number): Promise<void> {
    const tutorialCount = 6;
    const batchInsert = [];
    
    for (let i = 1; i <= tutorialCount; i++) {
      const tutorial: InsertTutorial = {
        userId,
        subjectId,
        name: `Tutorial ${i}`,
        completed: Math.random() > 0.5, // Randomly mark some as completed
        completedAt: Math.random() > 0.5 ? new Date() : null
      };
      
      batchInsert.push(tutorial);
    }
    
    await db.insert(tutorials).values(batchInsert);
  }

  // Helper method to create exam scores for a subject
  private async createExamScoresForSubject(userId: number, subjectId: number): Promise<void> {
    const testTypes = ['Quiz', 'Mid-term', 'Class Test', 'Final'];
    const batchInsert = [];
    
    for (let i = 0; i < testTypes.length; i++) {
      const randomMarks = Math.floor(Math.random() * 11) + 15; // 15-25 marks
      
      const examScore: InsertExamScore = {
        userId,
        subjectId,
        testName: testTypes[i],
        marks: randomMarks,
        totalMarks: 25,
        date: new Date(Date.now() - (i * 30 * 24 * 60 * 60 * 1000)) // Each test is a month apart
      };
      
      batchInsert.push(examScore);
    }
    
    await db.insert(examScores).values(batchInsert);
  }

  // Demo data initialization
  async initializeDemoData(): Promise<void> {
    // Check if data already exists
    const userCount = await db.select({ count: sql`count(*)` }).from(users);
    
    if (parseInt(userCount[0].count.toString()) > 0) {
      return; // Data already exists
    }
    
    // Create demo user
    const demoUser: InsertUser = {
      username: "student_demo",
      password: "password123",
      name: "Student Demo",
      email: "student@tcetmumbai.in"
    };
    
    const user = await this.createUser(demoUser);
    
    // Create subjects (Group 1)
    for (const subjectData of subjectGroups.group1) {
      const subject: InsertSubject = {
        name: subjectData.name,
        icon: subjectData.icon,
        color: subjectData.color,
        group: "group1"
      };
      
      const createdSubject = await this.createSubject(subject);
      
      // Create resources for this subject
      await this.createResourcesForSubject(createdSubject.id, subjectData.name);
      
      // Create practicals and tutorials
      await this.createPracticalsForSubject(user.id, createdSubject.id);
      
      if (subjectData.name.includes("Math")) {
        await this.createTutorialsForSubject(user.id, createdSubject.id);
      }
      
      // Create exam scores
      await this.createExamScoresForSubject(user.id, createdSubject.id);
    }
    
    // Create subjects (Group 2)
    for (const subjectData of subjectGroups.group2) {
      const subject: InsertSubject = {
        name: subjectData.name,
        icon: subjectData.icon,
        color: subjectData.color,
        group: "group2"
      };
      
      const createdSubject = await this.createSubject(subject);
      
      // Create resources for this subject
      await this.createResourcesForSubject(createdSubject.id, subjectData.name);
      
      // Create practicals and tutorials
      await this.createPracticalsForSubject(user.id, createdSubject.id);
      
      if (subjectData.name.includes("Math")) {
        await this.createTutorialsForSubject(user.id, createdSubject.id);
      }
      
      // Create exam scores
      await this.createExamScoresForSubject(user.id, createdSubject.id);
    }
    
    // Create demo tasks
    const demoTasks: InsertTask[] = [
      {
        userId: user.id,
        title: "Complete Mathematics Assignment",
        description: "Chapter 5 exercises, problems 1-10",
        dueDate: new Date(Date.now() + (2 * 24 * 60 * 60 * 1000)), // 2 days from now
        priority: "High",
        completed: false
      },
      {
        userId: user.id,
        title: "Read Physics Chapter 8",
        description: "Take notes on electromagnetism concepts",
        dueDate: new Date(Date.now() + (5 * 24 * 60 * 60 * 1000)), // 5 days from now
        priority: "Medium",
        completed: false
      },
      {
        userId: user.id,
        title: "Submit Chemistry Lab Report",
        description: "Experiment on titration",
        dueDate: new Date(Date.now() + (1 * 24 * 60 * 60 * 1000)), // 1 day from now
        priority: "High",
        completed: false
      }
    ];
    
    for (const task of demoTasks) {
      await this.createTask(task);
    }
    
    // Create demo activities
    const demoActivities: InsertActivity[] = [
      {
        userId: user.id,
        title: "Completed Practical 3 in Physics",
        type: "success",
        timestamp: new Date(Date.now() - (2 * 60 * 60 * 1000)) // 2 hours ago
      },
      {
        userId: user.id,
        title: "Scored 22/25 in Mathematics Quiz",
        type: "primary",
        timestamp: new Date(Date.now() - (1 * 24 * 60 * 60 * 1000)) // 1 day ago
      },
      {
        userId: user.id,
        title: "Downloaded Chemistry E-book",
        type: "info",
        timestamp: new Date(Date.now() - (3 * 24 * 60 * 60 * 1000)) // 3 days ago
      }
    ];
    
    for (const activity of demoActivities) {
      await this.createActivity(activity);
    }
    
    // Create achievements
    const achievementData: InsertAchievement[] = [
      // Task achievements
      {
        name: "Task Starter",
        description: "Complete your first task",
        icon: "checkbox",
        category: "tasks",
        pointsAwarded: 50,
        requiredCount: 1,
        level: 1
      },
      {
        name: "Task Master",
        description: "Complete 10 tasks",
        icon: "check-all",
        category: "tasks",
        pointsAwarded: 150,
        requiredCount: 10,
        level: 2
      },
      {
        name: "Productive Genius",
        description: "Complete 25 tasks",
        icon: "award",
        category: "tasks",
        pointsAwarded: 300,
        requiredCount: 25,
        level: 3
      },
      
      // Practical achievements
      {
        name: "Lab Rookie",
        description: "Complete your first practical",
        icon: "flask",
        category: "practicals",
        pointsAwarded: 50,
        requiredCount: 1,
        level: 1
      },
      {
        name: "Lab Technician",
        description: "Complete 10 practicals",
        icon: "microscope",
        category: "practicals",
        pointsAwarded: 150,
        requiredCount: 10,
        level: 2
      },
      {
        name: "Lab Scientist",
        description: "Complete 25 practicals",
        icon: "atom",
        category: "practicals",
        pointsAwarded: 300,
        requiredCount: 25,
        level: 3
      },
      
      // Tutorial achievements
      {
        name: "Tutorial Novice",
        description: "Complete your first tutorial",
        icon: "book",
        category: "tutorials",
        pointsAwarded: 50,
        requiredCount: 1,
        level: 1
      },
      {
        name: "Tutorial Expert",
        description: "Complete 10 tutorials",
        icon: "books",
        category: "tutorials",
        pointsAwarded: 150,
        requiredCount: 10,
        level: 2
      },
      {
        name: "Tutorial Master",
        description: "Complete 20 tutorials",
        icon: "graduation-cap",
        category: "tutorials",
        pointsAwarded: 300,
        requiredCount: 20,
        level: 3
      },
      
      // Exam achievements
      {
        name: "Top Scorer",
        description: "Score 80% or higher on an exam",
        icon: "star",
        category: "exams",
        pointsAwarded: 100,
        requiredCount: 1,
        level: 1
      },
      {
        name: "Exam Wizard",
        description: "Score 80% or higher on 5 exams",
        icon: "stars",
        category: "exams",
        pointsAwarded: 200,
        requiredCount: 5,
        level: 2
      },
      {
        name: "Academic Champion",
        description: "Score 80% or higher on 10 exams",
        icon: "trophy",
        category: "exams",
        pointsAwarded: 400,
        requiredCount: 10,
        level: 3
      },
      
      // Streak achievements
      {
        name: "Consistent Learner",
        description: "Log in for 3 days in a row",
        icon: "calendar-check",
        category: "streak",
        pointsAwarded: 75,
        requiredCount: 3,
        level: 1
      },
      {
        name: "Study Routine",
        description: "Log in for 7 days in a row",
        icon: "calendar-heart",
        category: "streak",
        pointsAwarded: 150,
        requiredCount: 7,
        level: 2
      },
      {
        name: "Dedicated Scholar",
        description: "Log in for 14 days in a row",
        icon: "calendar-star",
        category: "streak",
        pointsAwarded: 300,
        requiredCount: 14,
        level: 3
      }
    ];
    
    // Create achievements and associate with user
    for (const achievementInfo of achievementData) {
      const achievement = await this.createAchievement(achievementInfo);
      
      // Create user achievement
      await this.createUserAchievement({
        userId: user.id,
        achievementId: achievement.id,
        currentCount: 0,
        completed: false
      });
    }
    
    // Update user's streak
    await this.updateUserStreak(user.id, 2);
    
    // Check and update achievements based on current progress
    await this.checkAndUpdateUserAchievements(user.id);
  }
}