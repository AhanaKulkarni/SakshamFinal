import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import express, { Request, Response } from "express";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import { insertUserSchema, insertTaskSchema, insertActivitySchema, insertExamScoreSchema, insertAchievementSchema } from "@shared/schema";

// Extend Express Request type to include session
declare module "express-session" {
  interface SessionData {
    userId?: number;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  const apiRouter = express.Router();
  app.use("/api", apiRouter);

  // Auth routes
  apiRouter.post("/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }
      
      // We are relaxing the email validation to allow any email format
      // This is to be more flexible with credentials during development
      // In production, you might want to restrict to specific domains
      
      const user = await storage.getUserByEmail(email);
      
      if (!user || user.password !== password) {
        console.log(`Login attempt failed for email: ${email}`);
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Set user ID in session
      req.session.userId = user.id;
      
      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      
      console.log(`Login successful for user: ${user.name} (ID: ${user.id})`);
      res.status(200).json(userWithoutPassword);
      
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Registration endpoint
  apiRouter.post("/auth/register", async (req, res) => {
    try {
      const { username, password, name, email } = req.body;
      
      if (!username || !password || !name || !email) {
        return res.status(400).json({ message: "All fields are required" });
      }
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already in use" });
      }
      
      // Create new user
      const userData = { username, password, name, email };
      const validatedData = insertUserSchema.parse(userData);
      
      const newUser = await storage.createUser(validatedData);
      
      // Set user ID in session
      req.session.userId = newUser.id;
      
      // Return user without password
      const { password: _, ...userWithoutPassword } = newUser;
      res.status(201).json(userWithoutPassword);
      
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      console.error("Registration error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  apiRouter.post("/auth/logout", (req, res) => {
    req.session.destroy((err: Error | null) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  // User routes
  apiRouter.get("/users/me", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      console.log("Unauthorized attempt to access /api/users/me");
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const user = await storage.getUser(userId);
      
      if (!user) {
        console.log(`User ID ${userId} from session not found in database`);
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
      
      console.log(`User data successfully returned for user ${user.name} (ID: ${user.id})`);
    } catch (error) {
      console.error("Get current user error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Tasks routes
  apiRouter.get("/tasks", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const tasks = await storage.getUserTasks(userId);
      res.status(200).json(tasks);
    } catch (error) {
      console.error("Get tasks error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  apiRouter.post("/tasks", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const taskData = { ...req.body, userId };
      const validatedData = insertTaskSchema.parse(taskData);
      
      const newTask = await storage.createTask(validatedData);
      res.status(201).json(newTask);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      console.error("Create task error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.post("/tasks/:id", async (req, res) => {
    const userId = req.session.userId;
    const taskId = parseInt(req.params.id);
    const { completed } = req.body;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    if (isNaN(taskId)) {
      return res.status(400).json({ message: "Invalid task ID" });
    }
    
    if (typeof completed !== 'boolean') {
      return res.status(400).json({ message: "Completed status must be a boolean" });
    }
    
    try {
      const updatedTask = await storage.updateTask(taskId, completed);
      res.status(200).json(updatedTask);
    } catch (error) {
      console.error("Update task error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Activities routes
  apiRouter.get("/activities", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const activities = await storage.getUserActivities(userId);
      res.status(200).json(activities);
    } catch (error) {
      console.error("Get activities error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  apiRouter.post("/activities", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const activityData = { ...req.body, userId };
      const validatedData = insertActivitySchema.parse(activityData);
      
      const newActivity = await storage.createActivity(validatedData);
      res.status(201).json(newActivity);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      console.error("Create activity error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Resources routes
  apiRouter.get("/resources", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const group = req.query.group as string;
    
    try {
      const subjects = await storage.getSubjectsWithResources(group);
      res.status(200).json(subjects);
    } catch (error) {
      console.error("Get resources error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Subjects route
  apiRouter.get("/subjects", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const group = req.query.group as string;
    
    try {
      const subjects = await storage.getSubjects(group);
      res.status(200).json(subjects);
    } catch (error) {
      console.error("Get subjects error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Academic progress routes
  apiRouter.get("/academic-progress", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const progressData = await storage.getUserAcademicProgress(userId);
      res.status(200).json(progressData);
    } catch (error) {
      console.error("Get academic progress error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Exam performance routes
  apiRouter.get("/exam-performance", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const period = req.query.period as string || 'current';
    
    try {
      const performanceData = await storage.getUserExamPerformance(userId, period);
      res.status(200).json(performanceData);
    } catch (error) {
      console.error("Get exam performance error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  apiRouter.post("/exam-performance", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const examData = { ...req.body, userId };
      const validatedData = insertExamScoreSchema.parse(examData);
      
      const newExamScore = await storage.createExamScore(validatedData);
      res.status(201).json(newExamScore);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      console.error("Create exam score error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Reset exam scores endpoint
  apiRouter.post("/reset-exam-scores", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      await storage.resetUserExamScores(userId);
      console.log(`Exam scores reset for user ID: ${userId}`);
      res.status(200).json({ message: "All exam scores have been reset to zero" });
    } catch (error) {
      console.error("Reset exam scores error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Achievement routes
  apiRouter.get("/achievements", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const achievements = await storage.getUserAchievements(userId);
      res.status(200).json(achievements);
    } catch (error) {
      console.error("Get achievements error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/achievements/stats", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const stats = await storage.getUserStats(userId);
      res.status(200).json(stats);
    } catch (error) {
      console.error("Get achievement stats error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.post("/achievements/check", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      // Update user's streak
      const user = await storage.getUser(userId);
      if (user) {
        const today = new Date();
        let newStreak = user.streak;
        
        if (!user.lastActivityDate) {
          newStreak = 1;
        } else {
          const lastActivity = new Date(user.lastActivityDate);
          const timeDiff = today.getTime() - lastActivity.getTime();
          const daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
          
          if (daysDiff === 1) {
            // Login on consecutive day, increase streak
            newStreak = user.streak + 1;
          } else if (daysDiff > 1) {
            // Streak broken, reset to 1
            newStreak = 1;
          }
          // If same day, keep current streak
        }
        
        await storage.updateUserStreak(userId, newStreak);
      }
      
      // Check for new achievements
      const unlockedAchievements = await storage.checkAndUpdateUserAchievements(userId);
      
      res.status(200).json({ 
        unlockedAchievements,
        hasNewAchievements: unlockedAchievements.length > 0
      });
    } catch (error) {
      console.error("Check achievements error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Initialize some demo data if needed
  await storage.initializeDemoData();

  const httpServer = createServer(app);
  return httpServer;
}
