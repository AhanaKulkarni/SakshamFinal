# Saksham Portal - The Ultimate Academic Hub

A comprehensive academic management platform for engineering students, offering integrated tools for holistic academic support, performance tracking, and personalized learning experiences.

## Features

- **Personalized Dashboard**: Track your academic journey with an intuitive dashboard
- **Resource Library**: Access subject-specific learning materials
- **Academic Progress Tracking**: Monitor completion of tutorials and practicals
- **Exam Performance Analysis**: Visualize and analyze your exam scores
- **Task Management**: Organize your academic tasks with a to-do list
- **Achievement System**: Earn rewards and track your accomplishments

## Technology Stack

- **Frontend**: React.js with TypeScript
- **UI Components**: Shadcn UI with Tailwind CSS
- **Backend**: Node.js with Express
- **Database**: PostgreSQL
- **State Management**: React Query
- **Authentication**: Session-based authentication

## Getting Started

### Prerequisites

- Node.js (v18 or later)
- npm or yarn
- PostgreSQL database

### Installation

1. Clone the repository
   ```bash
   git clone https://github.com/yourusername/saksham-portal.git
   cd saksham-portal
   ```

2. Install dependencies
   ```bash
   npm install
   ```

3. Set up environment variables
   Create a `.env` file in the root directory with the following variables:
   ```
   DATABASE_URL=postgresql://username:password@localhost:5432/saksham
   SESSION_SECRET=your_session_secret
   ```

4. Run database migrations
   ```bash
   npm run db:push
   ```

5. Start the development server
   ```bash
   npm run dev
   ```

## Project Structure

- `/client`: React frontend application
- `/server`: Express backend API
- `/shared`: Shared types and utilities between frontend and backend

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.