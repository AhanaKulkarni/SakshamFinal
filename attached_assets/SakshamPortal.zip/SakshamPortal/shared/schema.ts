import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  points: integer("points").notNull().default(0),
  level: integer("level").notNull().default(1),
  streak: integer("streak").notNull().default(0),
  lastActivityDate: timestamp("last_activity_date"),
});

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
  group: text("group").notNull(),
});

export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  subjectId: integer("subject_id").notNull().references(() => subjects.id),
  title: text("title").notNull(),
  type: text("type").notNull(), // ebook, video, online
  url: text("url").notNull(),
  description: text("description"),
  icon: text("icon").notNull(),
});

export const practicals = pgTable("practicals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  subjectId: integer("subject_id").notNull().references(() => subjects.id),
  name: text("name").notNull(),
  completed: boolean("completed").notNull().default(false),
  completedAt: timestamp("completed_at"),
});

export const tutorials = pgTable("tutorials", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  subjectId: integer("subject_id").notNull().references(() => subjects.id),
  name: text("name").notNull(),
  completed: boolean("completed").notNull().default(false),
  completedAt: timestamp("completed_at"),
});

export const examScores = pgTable("exam_scores", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  subjectId: integer("subject_id").notNull().references(() => subjects.id),
  testName: text("test_name").notNull(),
  marks: integer("marks").notNull(),
  totalMarks: integer("total_marks").notNull(),
  date: timestamp("date").notNull(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: timestamp("due_date"),
  priority: text("priority").notNull(), // High, Medium, Low
  completed: boolean("completed").notNull().default(false),
  completedAt: timestamp("completed_at"),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  type: text("type").notNull(), // success, primary, info, warning
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  category: text("category").notNull(), // academic, participation, completion, etc.
  pointsAwarded: integer("points_awarded").notNull().default(0),
  requiredCount: integer("required_count").notNull().default(1),
  level: integer("level").notNull().default(1), // Bronze, Silver, Gold (1, 2, 3)
});

export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  achievementId: integer("achievement_id").notNull().references(() => achievements.id),
  currentCount: integer("current_count").notNull().default(0),
  completed: boolean("completed").notNull().default(false),
  unlockedAt: timestamp("unlocked_at"),
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertSubjectSchema = createInsertSchema(subjects).omit({ id: true });
export const insertResourceSchema = createInsertSchema(resources).omit({ id: true });
export const insertPracticalSchema = createInsertSchema(practicals).omit({ id: true });
export const insertTutorialSchema = createInsertSchema(tutorials).omit({ id: true });
export const insertExamScoreSchema = createInsertSchema(examScores).omit({ id: true });
export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true });
export const insertActivitySchema = createInsertSchema(activities).omit({ id: true });
export const insertAchievementSchema = createInsertSchema(achievements).omit({ id: true });
export const insertUserAchievementSchema = createInsertSchema(userAchievements).omit({ id: true });

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertSubject = z.infer<typeof insertSubjectSchema>;
export type InsertResource = z.infer<typeof insertResourceSchema>;
export type InsertPractical = z.infer<typeof insertPracticalSchema>;
export type InsertTutorial = z.infer<typeof insertTutorialSchema>;
export type InsertExamScore = z.infer<typeof insertExamScoreSchema>;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;

export type User = typeof users.$inferSelect;
export type Subject = typeof subjects.$inferSelect;
export type Resource = typeof resources.$inferSelect;
export type Practical = typeof practicals.$inferSelect;
export type Tutorial = typeof tutorials.$inferSelect;
export type ExamScore = typeof examScores.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type Activity = typeof activities.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;
export type UserAchievement = typeof userAchievements.$inferSelect;
